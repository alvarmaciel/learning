enunciado = """
Realizá un programa que permita que el usuario ingrese su nombre. El programa debe emitir
una salida con un mensaje de bienvenida que incluya el nombre ingresado. [EC]

leer nombre
armar el saludo
mostrar saludo

"""


print(enunciado)

nombre = input("Ingrese su nombre: ")
saludo = "Hola " + nombre + " que tal"
print(saludo)



