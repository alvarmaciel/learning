
a = 123456550
print("a:",a,"Tipo:",type(a))

a = "dhjkljdskl"
print("a:",a,"Tipo:",type(a))

print("Tipo de print:",type(print))


nombre = "juan"


numero_entero = 0
print("Numero:",numero_entero,numero_entero,nombre,a)

print(type(a))









