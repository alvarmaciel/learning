
q = "pepe"
a = 0
b = 'pepe'
c = 3.2
x = a
b = 789
a = "ljsagivkjfd"



