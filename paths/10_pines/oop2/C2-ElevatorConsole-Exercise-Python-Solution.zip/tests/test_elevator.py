#
# Developed by 10Pines SRL
# License: 
# This work is licensed under the 
# Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. 
# To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/ 
# or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View, 
# California, 94041, USA.
#  
import unittest
from src.ElevatorController import ElevatorController, ElevatorEmergency


class ElevatorTest(unittest.TestCase):

    def test01_elevator_starts_idle_with_door_open_on_floor_zero(self):
        elevator_controller = ElevatorController()

        self.assertTrue(elevator_controller.is_idle())
        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertTrue(elevator_controller.is_cabin_door_opened())
        self.assertEqual(0, elevator_controller.cabin_floor_number())

    def test02_cabin_door_starts_closing_when_elevator_gets_called(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)

        self.assertFalse(elevator_controller.is_idle())
        self.assertTrue(elevator_controller.is_working())

        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertFalse(elevator_controller.is_cabin_moving())

        self.assertFalse(elevator_controller.is_cabin_door_opened())
        self.assertFalse(elevator_controller.is_cabin_door_opening())
        self.assertTrue(elevator_controller.is_cabin_door_closing())
        self.assertFalse(elevator_controller.is_cabin_door_closed())

    def test03_cabin_starts_moving_when_door_gets_closed(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()

        self.assertFalse(elevator_controller.is_idle())
        self.assertTrue(elevator_controller.is_working())

        self.assertFalse(elevator_controller.is_cabin_stopped())
        self.assertTrue(elevator_controller.is_cabin_moving())

        self.assertFalse(elevator_controller.is_cabin_door_opened())
        self.assertFalse(elevator_controller.is_cabin_door_opening())
        self.assertFalse(elevator_controller.is_cabin_door_closing())
        self.assertTrue(elevator_controller.is_cabin_door_closed())

    def test04_cabin_stops_and_starts_opening_door_when_gets_to_destination(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()
        elevator_controller.cabin_on_floor(1)

        self.assertFalse(elevator_controller.is_idle())
        self.assertTrue(elevator_controller.is_working())

        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertFalse(elevator_controller.is_cabin_moving())

        self.assertFalse(elevator_controller.is_cabin_door_opened())
        self.assertTrue(elevator_controller.is_cabin_door_opening())
        self.assertFalse(elevator_controller.is_cabin_door_closing())
        self.assertFalse(elevator_controller.is_cabin_door_closed())

        self.assertEquals(1, elevator_controller.cabin_floor_number())

    def test05_elevator_gets_idle_when_door_get_opened(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()
        elevator_controller.cabin_on_floor(1)
        elevator_controller.cabin_door_opened()

        self.assertTrue(elevator_controller.is_idle())
        self.assertFalse(elevator_controller.is_working())

        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertFalse(elevator_controller.is_cabin_moving())

        self.assertTrue(elevator_controller.is_cabin_door_opened())
        self.assertFalse(elevator_controller.is_cabin_door_opening())
        self.assertFalse(elevator_controller.is_cabin_door_closing())
        self.assertFalse(elevator_controller.is_cabin_door_closed())

        self.assertEquals(1, elevator_controller.cabin_floor_number())

    # STOP HERE!

    def test06_door_keeps_opened_when_opening_is_requested(self):
        elevator_controller = ElevatorController()

        self.assertTrue(elevator_controller.is_cabin_door_opened())

        elevator_controller.open_cabin_door()

        self.assertTrue(elevator_controller.is_cabin_door_opened())

    def test07_door_must_be_opened_when_cabin_is_stopped_and_closing_doors(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)

        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertTrue(elevator_controller.is_cabin_door_closing())

        elevator_controller.open_cabin_door()
        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertTrue(elevator_controller.is_cabin_door_opening())

    def test08_can_not_open_door_when_cabin_is_moving(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()

        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_moving())
        self.assertTrue(elevator_controller.is_cabin_door_closed())

        elevator_controller.open_cabin_door()
        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_moving())
        self.assertTrue(elevator_controller.is_cabin_door_closed())

    def test09_door_keeps_openeing_when_it_is_openeing(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()
        elevator_controller.cabin_on_floor(1)

        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertTrue(elevator_controller.is_cabin_door_opening())

        elevator_controller.open_cabin_door()
        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertTrue(elevator_controller.is_cabin_door_opening())

    # STOP HERE!!

    def test10_request_to_go_up_are_enqueue_when_requested_when_cabin_is_moving(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()
        elevator_controller.cabin_on_floor(1)
        elevator_controller.go_up_pushed_from_floor(2)
        elevator_controller.cabin_door_opened()

        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_waiting_for_people())
        self.assertTrue(elevator_controller.is_cabin_door_opened())

    def test11_cabin_door_start_closing_after_waiting_for_people(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()
        elevator_controller.cabin_on_floor(1)
        elevator_controller.go_up_pushed_from_floor(2)
        elevator_controller.cabin_door_opened()
        elevator_controller.wait_for_people_timed_out()

        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertTrue(elevator_controller.is_cabin_door_closing())

    def test12_stops_waiting_for_people_if_close_door_is_pressed(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()
        elevator_controller.cabin_on_floor(1)
        elevator_controller.go_up_pushed_from_floor(2)
        elevator_controller.cabin_door_opened()

        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_waiting_for_people())
        self.assertTrue(elevator_controller.is_cabin_door_opened())

        elevator_controller.close_cabin_door()

        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertTrue(elevator_controller.is_cabin_door_closing())

    def test13_close_door_does_nothing_if_idle(self):
        elevator_controller = ElevatorController()

        elevator_controller.close_cabin_door()

        self.assertTrue(elevator_controller.is_idle())
        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertTrue(elevator_controller.is_cabin_door_opened())

    def test14_close_door_does_nothing_when_cabin_is_moving(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()

        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_moving())
        self.assertTrue(elevator_controller.is_cabin_door_closed())

        elevator_controller.close_cabin_door()

        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_moving())
        self.assertTrue(elevator_controller.is_cabin_door_closed())

    def test15_close_door_does_nothing_when_opening_the_door_to_wait_for_people(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()
        elevator_controller.cabin_on_floor(1)

        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertTrue(elevator_controller.is_cabin_door_opening())

        elevator_controller.close_cabin_door()

        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertTrue(elevator_controller.is_cabin_door_opening())

    # STOP HERE!!

    def test16_elevator_has_to_enter_emergency_if_stopped_and_other_floor_sensor_turns_on(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()
        elevator_controller.cabin_on_floor(1)
        try:
            elevator_controller.cabin_on_floor(0)
            self.fail()
        except ElevatorEmergency as elevator_emergency:
            self.assertTrue(str(elevator_emergency) == "Sensor de cabina desincronizado")

    def test17_elevator_has_to_enter_emergency_if_falling(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(2)
        elevator_controller.cabin_door_closed()
        elevator_controller.cabin_on_floor(1)
        try:
            elevator_controller.cabin_on_floor(0)
            self.fail()
        except ElevatorEmergency as elevator_emergency:
            self.assertTrue(str(elevator_emergency) == "Sensor de cabina desincronizado")

    def test18_elevator_has_to_enter_emergency_if_jumps_floors(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(3)
        elevator_controller.cabin_door_closed()
        try:
            elevator_controller.cabin_on_floor(3)
            self.fail()
        except ElevatorEmergency as elevator_emergency:
            self.assertTrue(str(elevator_emergency) == "Sensor de cabina desincronizado")

    def test19_elevator_has_to_enter_emergency_if_door_closes_automatically(self):
        elevator_controller = ElevatorController()

        try:
            elevator_controller.cabin_door_closed()
            self.fail()
        except ElevatorEmergency as elevator_emergency:
            self.assertTrue(str(elevator_emergency) == "Sensor de puerta desincronizado")

    def test20_elevator_has_to_enter_emergency_if_door_closed_sensor_turns_on_when_closed(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()
        try:
            elevator_controller.cabin_door_closed()
            self.fail()
        except ElevatorEmergency as elevator_emergency:
            self.assertTrue(str(elevator_emergency) == "Sensor de puerta desincronizado")

    def test21_elevator_has_to_enter_emergency_if_door_closes_when_opening(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()
        elevator_controller.cabin_on_floor(1)
        try:
            elevator_controller.cabin_door_closed()
            self.fail()
        except ElevatorEmergency as elevator_emergency:
            self.assertTrue(str(elevator_emergency) == "Sensor de puerta desincronizado")

    # STOP HERE!!
    # More tests here to verify bad sensor function

    def test22_cabin_has_to_stop_on_the_floors_on_its_way(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()
        elevator_controller.go_up_pushed_from_floor(2)
        elevator_controller.cabin_on_floor(1)

        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertTrue(elevator_controller.is_cabin_door_opening())

    def test23_elevator_completes_all_the_requests(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()
        elevator_controller.go_up_pushed_from_floor(2)
        elevator_controller.cabin_on_floor(1)
        elevator_controller.cabin_door_opened()
        elevator_controller.wait_for_people_timed_out()
        elevator_controller.cabin_door_closed()
        elevator_controller.cabin_on_floor(2)

        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertTrue(elevator_controller.is_cabin_door_opening())

    def test24_cabin_has_to_stop_on_floors_on_its_way_no_matter_how_they_well_called(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(2)
        elevator_controller.cabin_door_closed()
        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_on_floor(1)

        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertTrue(elevator_controller.is_cabin_door_opening())

    def test25_cabin_has_to_stop_and_wait_for_people_on_floors_on_its_way_no_matter_how_they_well_called(self):
        elevator_controller = ElevatorController()

        elevator_controller.go_up_pushed_from_floor(2)
        elevator_controller.cabin_door_closed()
        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_on_floor(1)
        elevator_controller.cabin_door_opened()
        elevator_controller.wait_for_people_timed_out()

        self.assertTrue(elevator_controller.is_working())
        self.assertTrue(elevator_controller.is_cabin_stopped())
        self.assertTrue(elevator_controller.is_cabin_door_closing())
