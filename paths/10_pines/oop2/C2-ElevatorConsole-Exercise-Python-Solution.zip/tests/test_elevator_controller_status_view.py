#
# Developed by 10Pines SRL
# License: 
# This work is licensed under the 
# Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. 
# To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/ 
# or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View, 
# California, 94041, USA.
#  
import unittest
from src.ElevatorController import ElevatorController
from src.ElevatorControllerView import ElevatorControllerConsole, ElevatorControllerStatusView


class ElevatorControllerViewTest(unittest.TestCase):

    def test01_elevator_controller_console_tracks_door_closing_state(self):
        elevator_controller = ElevatorController()
        elevator_controller_console = ElevatorControllerConsole(elevator_controller)

        elevator_controller.go_up_pushed_from_floor(1)

        lines = elevator_controller_console.lines()

        self.assertEquals(1, len(lines))
        self.assertEquals("Puerta Cerrandose", lines[0])

    def test02_elevator_controller_console_tracks_cabin_state(self):
        elevator_controller = ElevatorController()
        elevator_controller_console = ElevatorControllerConsole(elevator_controller)

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()

        lines = elevator_controller_console.lines()

        self.assertEquals(3, len(lines))
        self.assertEquals("Puerta Cerrandose", lines[0])
        self.assertEquals("Puerta Cerrada", lines[1])
        self.assertEquals("Cabina Moviendose", lines[2])

    def test03_elevator_controller_console_tracks_cabin_and_door_state_changes(self):
        elevator_controller = ElevatorController()
        elevator_controller_console = ElevatorControllerConsole(elevator_controller)

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()
        elevator_controller.cabin_on_floor(1)

        lines = elevator_controller_console.lines()

        self.assertEquals(5, len(lines))
        self.assertEquals("Puerta Cerrandose", lines[0])
        self.assertEquals("Puerta Cerrada", lines[1])
        self.assertEquals("Cabina Moviendose", lines[2])
        self.assertEquals("Cabina Detenida", lines[3])
        self.assertEquals("Puerta Abriendose", lines[4])

    def test04_elevator_controller_can_have_more_than_one_view(self):
        elevator_controller = ElevatorController()
        elevator_controller_console = ElevatorControllerConsole(elevator_controller)
        elevator_controller_status_view = ElevatorControllerStatusView(elevator_controller)

        elevator_controller.go_up_pushed_from_floor(1)
        elevator_controller.cabin_door_closed()
        elevator_controller.cabin_on_floor(1)

        lines = elevator_controller_console.lines()

        self.assertEquals(5, len(lines))
        self.assertEquals("Puerta Cerrandose", lines[0])
        self.assertEquals("Puerta Cerrada", lines[1])
        self.assertEquals("Cabina Moviendose", lines[2])
        self.assertEquals("Cabina Detenida", lines[3])
        self.assertEquals("Puerta Abriendose", lines[4])

        self.assertEquals("Stopped", elevator_controller_status_view.cabin_state_field_model())
        self.assertEquals("Opening", elevator_controller_status_view.cabin_door_state_field_model())
