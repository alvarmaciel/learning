#
# Developed by 10Pines SRL
# License: 
# This work is licensed under the 
# Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. 
# To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/ 
# or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View, 
# California, 94041, USA.
# 

class ActiveVariable:

    def __init__(self):
        self._observers = []

    def set(self, a_value):
        self._value = a_value
        self.notify_observers()

    def get(self):
        return self._value

    def add_observer(self, an_observer):
        self._observers.append(an_observer)

    def notify_observers(self):
        for observer in self._observers:
            observer(self._value)


class ElevatorEmergency(Exception):
    pass


class CabinDoorState:

    def accept(self, a_visitor):
        self.should_be_implemented_by_subclass()

    def is_opened(self):
        self.should_be_implemented_by_subclass()

    def is_opening(self):
        self.should_be_implemented_by_subclass()

    def is_closing(self):
        self.should_be_implemented_by_subclass()

    def is_closed(self):
        self.should_be_implemented_by_subclass()

    def cabin_door_closed_when_working_and_cabin_stopped(self):
        self.should_be_implemented_by_subclass()

    def open_cabin_door_when_working_and_cabin_stopped(self):
        self.should_be_implemented_by_subclass()

    def close_cabin_door_when_working_and_cabin_stopped(self):
        self.should_be_implemented_by_subclass()

    def should_be_implemented_by_subclass(self):
        raise RuntimeError("Should be implemented by subclass")


class CabinDoorClosingState(CabinDoorState):

    def __init__(self, elevator_controller):
        self.elevator_controller = elevator_controller

    def accept(self, a_visitor):
        return a_visitor.visit_cabin_door_closing_state(self)

    def is_opened(self):
        return False

    def is_opening(self):
        return False

    def is_closing(self):
        return True

    def is_closed(self):
        return False

    def cabin_door_closed_when_working_and_cabin_stopped(self):
        self.elevator_controller.cabin_door_closed_when_working_and_cabin_stopped_and_closing()

    def open_cabin_door_when_working_and_cabin_stopped(self):
        self.elevator_controller.open_cabin_door_when_working_and_cabin_stopped_and_door_closing()

    def close_cabin_door_when_working_and_cabin_stopped(self):
        raise NotImplementedError()


class CabinDoorOpenedState(CabinDoorState):

    def __init__(self, elevator_controller):
        self.elevator_controller = elevator_controller

    def accept(self, a_visitor):
        return a_visitor.visit_cabin_door_opened_state(self)

    def is_opened(self):
        return True

    def is_opening(self):
        return False

    def is_closing(self):
        return False

    def is_closed(self):
        return False

    def cabin_door_closed_when_working_and_cabin_stopped(self):
        raise NotImplementedError()

    def close_cabin_door_when_working_and_cabin_stopped(self):
        raise NotImplementedError()

    def open_cabin_door_when_working_and_cabin_stopped(self):
        raise NotImplementedError()


class CabinDoorClosedState(CabinDoorState):

    def __init__(self, elevator_controller):
        self.elevator_controller = elevator_controller

    def accept(self, a_visitor):
        return a_visitor.visit_cabin_door_closed_state(self)

    def is_opened(self):
        return False

    def is_opening(self):
        return False

    def is_closing(self):
        return False

    def is_closed(self):
        return True

    def cabin_door_closed_when_working_and_cabin_stopped(self):
        raise NotImplementedError()

    def open_cabin_door_when_working_and_cabin_stopped(self):
        raise NotImplementedError()

    def close_cabin_door_when_working_and_cabin_stopped(self):
        raise NotImplementedError()


class CabinDoorOpeningState(CabinDoorState):

    def __init__(self, elevator_controller):
        self.elevator_controller = elevator_controller

    def accept(self, a_visitor):
        return a_visitor.visit_cabin_door_opening_state(self)

    def is_opened(self):
        return False

    def is_opening(self):
        return True

    def is_closing(self):
        return False

    def is_closed(self):
        return False

    def cabin_door_closed_when_working_and_cabin_stopped(self):
        self.elevator_controller.cabin_door_closed_when_working_and_cabin_stopped_and_cabin_door_opening();

    def open_cabin_door_when_working_and_cabin_stopped(self):
        self.elevator_controller.open_cabin_door_when_working_and_cabin_stopped_and_cabin_door_opening();

    def close_cabin_door_when_working_and_cabin_stopped(self):
        self.elevator_controller.close_cabin_door_when_working_and_cabin_stopped_and_cabin_door_opening();


class CabinState:

    def accept(self, a_visitor):
        self.should_be_implemented_by_subclass()

    def cabin_door_closed_when_working(self):
        self.should_be_implemented_by_subclass()

    def is_moving(self):
        self.should_be_implemented_by_subclass()

    def is_stopped(self):
        self.should_be_implemented_by_subclass()

    def cabin_door_opened_when_working(self):
        self.should_be_implemented_by_subclass()

    def open_cabin_door_when_working(self):
        self.should_be_implemented_by_subclass()

    def is_waiting_for_people(self):
        self.should_be_implemented_by_subclass()

    def close_cabin_door_when_working(self):
        self.should_be_implemented_by_subclass()

    def wait_for_people_timed_out_when_working(self):
        self.should_be_implemented_by_subclass()

    def should_be_implemented_by_subclass(self):
        raise RuntimeError("Should be implemented by subclass")


class CabinStoppedState(CabinState):

    def __init__(self, elevator_controller):
        self.elevator_controller = elevator_controller

    def accept(self, a_visitor):
        return a_visitor.visit_cabin_stopped_state(self)

    def cabin_door_closed_when_working(self):
        self.elevator_controller.cabin_door_closed_when_working_and_cabin_stopped();

    def is_moving(self):
        return False

    def is_stopped(self):
        return True

    def cabin_door_opened_when_working(self):
        self.elevator_controller.cabin_door_opened_when_working_and_cabin_stopped()

    def open_cabin_door_when_working(self):
        self.elevator_controller.open_cabin_door_when_working_and_cabin_stopped()

    def is_waiting_for_people(self):
        return False

    def close_cabin_door_when_working(self):
        self.elevator_controller.close_cabin_door_when_working_and_cabin_stopped()

    def wait_for_people_timed_out_when_working(self):
        raise NotImplementedError()


class CabinMovingState(CabinState):

    def __init__(self, elevator_controller):
        self.elevator_controller = elevator_controller

    def accept(self, a_visitor):
        return a_visitor.visit_cabin_moving_state(self)

    def cabin_door_closed_when_working(self):
        self.elevator_controller.cabin_door_closed_when_working_and_cabin_moving()

    def is_moving(self):
        return True

    def is_stopped(self):
        return False

    def cabin_door_opened_when_working(self):
        raise NotImplementedError()

    def open_cabin_door_when_working(self):
        self.elevator_controller.open_cabin_door_when_working_and_cabin_moving()

    def is_waiting_for_people(self):
        return False

    def close_cabin_door_when_working(self):
        self.elevator_controller.close_cabin_door_when_working_and_cabin_moving()

    def wait_for_people_timed_out_when_working(self):
        raise NotImplementedError()


class CabinWaitingForPeopleState(CabinState):

    def __init__(self, elevator_controller):
        self.elevator_controller = elevator_controller

    def accept(self, a_visitor):
        return a_visitor.visit_cabin_waiting_for_people_state(self)

    def cabin_door_closed_when_working(self):
        raise NotImplementedError()

    def is_moving(self):
        raise NotImplementedError()

    def is_stopped(self):
        return False

    def cabin_door_opened_when_working(self):
        raise NotImplementedError()

    def open_cabin_door_when_working(self):
        raise NotImplementedError()

    def is_waiting_for_people(self):
        return True

    def close_cabin_door_when_working(self):
        self.elevator_controller.close_cabin_door_when_working_and_cabin_waiting_for_people();

    def wait_for_people_timed_out_when_working(self):
        self.elevator_controller.wait_for_people_timed_out_when_working_and_cabin_waiting_for_people();


class ElevatorControllerState:

    def is_idle(self):
        raise "Should be implemented by subclass"

    def go_up_pushed_from_floor(self, a_floor_number):
        raise "Should be implemented by subclass"

    def is_working(self):
        raise "Should be implemented by subclass"

    def cabind_door_closed(self):
        raise "Should be implemented by subclass"

    def cabin_on_floor(self, a_floor_number):
        raise "Should be implemented by subclass"

    def cabin_door_opened(self):
        raise "Should be implemented by subclass"

    def open_cabin_door(self):
        raise "Should be implemented by subclass"

    def wait_for_people_timed_out(self):
        raise "Should be implemented by subclass"

    def close_cabin_door(self):
        raise "Should be implemented by subclass"


class ElevatorControllerIdleState(ElevatorControllerState):

    def __init__(self, elevator_controller):
        self.elevator_controller = elevator_controller

    def is_idle(self):
        return True

    def go_up_pushed_from_floor(self, a_floor_number):
        self.elevator_controller.go_up_pushed_from_floor_when_idle(a_floor_number)

    def is_working(self):
        return False

    def cabind_door_closed(self):
        self.elevator_controller.cabin_door_closed_when_idle()

    def cabin_on_floor(self, a_floor_number):
        self.elevator_controller.cabin_on_floor_when_idle(a_floor_number)

    def cabin_door_opened(self):
        raise NotImplementedError()

    def open_cabin_door(self):
        self.elevator_controller.open_cabin_door_when_idle()

    def close_cabin_door(self):
        self.elevator_controller.close_cabin_door_when_idle()

    def wait_for_people_timed_out(self):
        raise NotImplementedError()


class ElevatorControllerIsWorkingState(ElevatorControllerState):

    def __init__(self, elevator_controller):
        self.elevator_controller = elevator_controller

    def go_up_pushed_from_floor(self, a_floor_number):
        self.elevator_controller.go_up_pushed_from_floor_when_working(a_floor_number)

    def is_idle(self):
        return False

    def is_working(self):
        return True

    def cabind_door_closed(self):
        self.elevator_controller.cabin_door_closed_when_working()

    def cabin_on_floor(self, a_floor_number):
        self.elevator_controller.cabin_on_floor_when_working(a_floor_number)

    def cabin_door_opened(self):
        self.elevator_controller.cabin_door_openend_when_working()

    def open_cabin_door(self):
        self.elevator_controller.open_cabin_door_when_working()

    def wait_for_people_timed_out(self):
        self.elevator_controller.wait_for_people_timed_out_when_working()

    def close_cabin_door(self):
        self.elevator_controller.close_cabin_door_when_working()


class ElevatorController:

    def __init__(self):
        self._cabin_door_state = ActiveVariable()
        self._cabin_state = ActiveVariable()

        self.controller_is_idle()
        self.cabin_is_stopped()
        self.cabin_door_is_opened()
        self._cabin_floor_number = 0
        self._floors_to_go = []

    def add_cabin_door_state_observer(self, an_observer):
        self._cabin_door_state.add_observer(an_observer)

    def add_cabin_state_observer(self, an_observer):
        self._cabin_state.add_observer(an_observer)

    def cabin_door_is_opened(self):
        self._cabin_door_state.set(CabinDoorOpenedState(self))

    def cabin_is_stopped(self):
        self._cabin_state.set(CabinStoppedState(self))

    def controller_is_idle(self):
        self._state = ElevatorControllerIdleState(self)

    # Elevator state
    def is_idle(self):
        return self._state.is_idle()

    def is_working(self):
        return self._state.is_working()

    # Door state
    def is_cabin_door_opened(self):
        return self._cabin_door_state.get().is_opened()

    def is_cabin_door_opening(self):
        return self._cabin_door_state.get().is_opening()

    def is_cabin_door_closed(self):
        return self._cabin_door_state.get().is_closed()

    def is_cabin_door_closing(self):
        return self._cabin_door_state.get().is_closing()

    # Cabin state
    def cabin_floor_number(self):
        return self._cabin_floor_number

    def is_cabin_stopped(self):
        return self._cabin_state.get().is_stopped()

    def is_cabin_moving(self):
        return self._cabin_state.get().is_moving()

    def is_cabin_waiting_for_people(self):
        return self._cabin_state.get().is_waiting_for_people()

    # Events
    def go_up_pushed_from_floor(self, a_floor_number):
        self._state.go_up_pushed_from_floor(a_floor_number)

    def cabin_on_floor(self, a_floor_number):
        self._state.cabin_on_floor(a_floor_number)

    def cabin_door_closed(self):
        self._state.cabind_door_closed()

    def open_cabin_door(self):
        self._state.open_cabin_door()

    def cabin_door_opened(self):
        self._state.cabin_door_opened()

    def wait_for_people_timed_out(self):
        self._state.wait_for_people_timed_out()

    def close_cabin_door(self):
        self._state.close_cabin_door()

    def go_up_pushed_from_floor_when_idle(self, a_floor_number):
        self.append_to_floors_to_go(a_floor_number)
        self.controller_is_working()
        self.cabin_door_is_closing()

    def cabin_door_is_closing(self):
        self._cabin_door_state.set(CabinDoorClosingState(self))

    def controller_is_working(self):
        self._state = ElevatorControllerIsWorkingState(self)

    def cabin_door_closed_when_working(self):
        self._cabin_state.get().cabin_door_closed_when_working()

    def cabin_door_closed_when_working_and_cabin_stopped(self):
        self._cabin_door_state.get().cabin_door_closed_when_working_and_cabin_stopped()

    def cabin_door_closed_when_working_and_cabin_stopped_and_closing(self):
        self._cabin_door_state.set(CabinDoorClosedState(self))
        self._cabin_state.set(CabinMovingState(self))

    def cabin_on_floor_when_working(self, a_floor_number):
        if (a_floor_number < self._cabin_floor_number):
            raise ElevatorEmergency("Sensor de cabina desincronizado")
        if (self._cabin_floor_number + 1 != a_floor_number):
            raise ElevatorEmergency("Sensor de cabina desincronizado")

        self._cabin_floor_number = a_floor_number
        if (self._floors_to_go[0] == a_floor_number):
            self._floors_to_go.pop(0)
            self.cabin_is_stopped()
            self.cabin_door_is_opening()

    def cabin_door_is_opening(self):
        self._cabin_door_state.set(CabinDoorOpeningState(self))

    def cabin_on_floor_when_idle(self, a_floor_number):
        raise ElevatorEmergency("Sensor de cabina desincronizado")

    def cabin_door_openend_when_working(self):
        self._cabin_state.get().cabin_door_opened_when_working()

    def cabin_door_opened_when_working_and_cabin_stopped(self):
        self.cabin_door_is_opened()
        if (self.has_floor_to_go()):
            self.cabin_is_waiting_for_people()
        else:
            self.controller_state_is_idle()

    def cabin_is_waiting_for_people(self):
        self._cabin_state.set(CabinWaitingForPeopleState(self))

    def controller_state_is_idle(self):
        self._state = ElevatorControllerIdleState(self)

    def has_floor_to_go(self):
        return len(self._floors_to_go) > 0

    def open_cabin_door_when_idle(self):
        # No hago nada porque me pidieron abrir la puerta cuando no estoy haciendo nada
        # y en ese caso ya esta abierta
        pass

    def open_cabin_door_when_working(self):
        self._cabin_state.get().open_cabin_door_when_working()

    def open_cabin_door_when_working_and_cabin_stopped(self):
        self._cabin_door_state.get().open_cabin_door_when_working_and_cabin_stopped()

    def open_cabin_door_when_working_and_cabin_stopped_and_door_closing(self):
        self.cabin_door_is_opening()

    def open_cabin_door_when_working_and_cabin_moving(self):
        # No puedo abrir la puerta porque la cabina se esta moviendo!
        pass

    def open_cabin_door_when_working_and_cabin_stopped_and_cabin_door_opening(self):
        # Ya se esta abriendo!! no tengo que hacer nada
        pass

    def go_up_pushed_from_floor_when_working(self, a_floor_number):
        self.append_to_floors_to_go(a_floor_number)

    def append_to_floors_to_go(self, a_floor_number):
        self._floors_to_go.append(a_floor_number)
        self._floors_to_go.sort()

    def wait_for_people_timed_out_when_working(self):
        self._cabin_state.get().wait_for_people_timed_out_when_working()

    def wait_for_people_timed_out_when_working_and_cabin_waiting_for_people(self):
        self.cabin_is_stopped()
        self.cabin_door_is_closing()

    def close_cabin_door_when_working(self):
        self._cabin_state.get().close_cabin_door_when_working()

    def close_cabin_door_when_working_and_cabin_waiting_for_people(self):
        self.wait_for_people_timed_out_when_working_and_cabin_waiting_for_people()

    def close_cabin_door_when_idle(self):
        # No estoy haciendo nada y me piden cerrar la puerta, por lo tanto no la
        # cierro porque no tengo que mover la cabina puesto que estoy idle
        pass

    def close_cabin_door_when_working_and_cabin_moving(self):
        # Si la cabina se esta moviendo, la puerta ya esta cerrada, por lo tanto
        # no tengo que volver a cerrarla
        pass

    def close_cabin_door_when_working_and_cabin_stopped(self):
        self._cabin_door_state.get().close_cabin_door_when_working_and_cabin_stopped()

    def close_cabin_door_when_working_and_cabin_stopped_and_cabin_door_opening(self):
        # Estoy abriendo la puerta para que suba gente y me piden cerrarla.
        # No la cierro hasta no abrir completamente la puerta
        pass

    def cabin_door_closed_when_idle(self):
        raise ElevatorEmergency("Sensor de puerta desincronizado")

    def cabin_door_closed_when_working_and_cabin_moving(self):
        raise ElevatorEmergency("Sensor de puerta desincronizado")

    def cabin_door_closed_when_working_and_cabin_stopped_and_cabin_door_opening(self):
        raise ElevatorEmergency("Sensor de puerta desincronizado")
