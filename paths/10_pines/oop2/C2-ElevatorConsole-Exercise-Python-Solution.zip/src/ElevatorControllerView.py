class ElevatorControllerConsole:
    def __init__(self, elevator_controller):
        self._lines = []
        elevator_controller.add_cabin_door_state_observer(
            lambda cabin_door_state: self.cabin_door_state_changed_to(cabin_door_state))
        elevator_controller.add_cabin_state_observer(
            lambda cabin_state: self.cabin_state_changed_to(cabin_state))

    def cabin_door_state_changed_to(self, cabin_door_state):
        cabin_door_state.accept(self)

    def cabin_state_changed_to(self, cabin_state):
        cabin_state.accept(self)

    def visit_cabin_door_closing_state(self, cabin_door_closing_state):
        self._lines.append("Puerta Cerrandose")

    def visit_cabin_door_closed_state(self, cabin_door_closed_state):
        self._lines.append("Puerta Cerrada")

    def visit_cabin_door_opened_state(self, cabin_door_opened_state):
        self._lines.append("Puerta Abierta")

    def visit_cabin_door_opening_state(self, cabin_door_opening_state):
        self._lines.append("Puerta Abriendose")

    def visit_cabin_moving_state(self, cabin_moving_state):
        self._lines.append("Cabina Moviendose")

    def visit_cabin_stopped_state(self, cabin_stopped_state):
        self._lines.append("Cabina Detenida")

    def visit_cabin_waiting_people_state(self, cabin_waiting_for_people_state):
        self._lines.append("Cabina Esperando por Gente")

    def lines(self):
        return self._lines


class ElevatorControllerStatusView:
    def __init__(self, elevator_controller):
        elevator_controller.add_cabin_door_state_observer(
            lambda cabin_door_state: self.cabin_door_state_changed_to(cabin_door_state))
        elevator_controller.add_cabin_state_observer(
            lambda cabin_state: self.cabin_state_changed_to(cabin_state))

    def cabin_door_state_changed_to(self, cabin_door_state):
        cabin_door_state.accept(self)

    def cabin_state_changed_to(self, cabin_state):
        cabin_state.accept(self)

    def visit_cabin_door_closing_state(self, cabin_door_closing_state):
        self._cabin_door_state_field_model = "Closing"

    def visit_cabin_door_closed_state(self, cabin_door_closed_state):
        self._cabin_door_state_field_model = "Closed"

    def visit_cabin_door_opened_state(self, cabin_door_opened_state):
        self._cabin_door_state_field_model = "Opened"

    def visit_cabin_door_opening_state(self, cabin_door_opening_state):
        self._cabin_door_state_field_model = "Opening"

    def visit_cabin_moving_state(self, cabin_moving_state):
        self._cabin_state_field_model = "Moving"

    def visit_cabin_stopped_state(self, cabin_stopped_state):
        self._cabin_state_field_model = "Stopped"

    def visit_cabin_waiting_people_state(self, cabin_waiting_for_people_state):
        self._cabin_state_field_model = "Waiting For People"

    def cabin_state_field_model(self):
        return self._cabin_state_field_model

    def cabin_door_state_field_model(self):
        return self._cabin_door_state_field_model
