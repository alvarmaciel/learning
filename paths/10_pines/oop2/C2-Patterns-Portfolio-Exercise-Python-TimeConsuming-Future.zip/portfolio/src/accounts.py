from abc import ABCMeta, abstractmethod
from copy import copy
from functools import reduce

from transactions import AccountTransactionVisitor


class SummarizingAccount(metaclass=ABCMeta):
    @abstractmethod
    def balance(self):
        pass

    @abstractmethod
    def has_registered(self, transaction):
        pass

    @abstractmethod
    def manages(self, account):
        pass

    @abstractmethod
    def transactions(self):
        pass

    @abstractmethod
    def accept_transactions_visitor(self, a_visitor):
        pass

    @abstractmethod
    def accept(self, a_visitor):
        pass


class ReceptiveAccount(SummarizingAccount):
    def __init__(self):
        self._transactions = []

    def balance(self):
        return BalanceVisitor(self).value()

    def register(self, a_transaction):
        self._transactions.append(a_transaction)
        return a_transaction

    def has_registered(self, transaction):
        return transaction in self._transactions

    def manages(self, account):
        return self == account

    def transactions(self):
        return copy(self._transactions)

    def accept_transactions_visitor(self, a_visitor):
        for transaction in self._transactions:
            transaction.accept(a_visitor)

    def accept(self, a_visitor):
        a_visitor.visit_receptive_account(self)


class Portfolio(SummarizingAccount):
    ACCOUNT_ALREADY_MANAGED = "La cuenta ya esta manejada por otro portfolio"

    @classmethod
    def create_with(cls, an_account, another_account):
        portfolio = cls()
        portfolio.add_account(an_account)
        portfolio.add_account(another_account)
        return portfolio

    def __init__(self):
        self._accounts = []

    def balance(self):
        # return reduce(
        #              lambda balance,account: balance+account.balance(),
        #              self._accounts, 0)
        # return sum(map(lambda account: account.balance(), self._accounts))
        return sum(account.balance() for account in self._accounts)

    def has_registered(self, transaction):
        # return reduce(
        #              lambda result,account: result or account.hasRegistered(transaction),
        #              self._accounts, False)
        # return any(map(lambda account: account.hasRegistered(transaction),self._accounts))
        return any(account.has_registered(transaction) for account in self._accounts)

    def manages(self, an_account):
        # return reduce(
        #            lambda result,account: result or account.manages(anAccount),
        #            self._accounts, self==anAccount)
        # return self==anAccount or any(map(lambda account: account.manages(anAccount),self._accounts))
        return self == an_account or any(account.manages(an_account) for account in self._accounts)

    def transactions(self):
        return reduce(lambda transactions, account: transactions + account.transactions(), self._accounts, [])

    def add_account(self, account):
        self._assert_not_already_managed(account)

        self._accounts.append(account)

    def _assert_not_already_managed(self, account):
        if self.manages(account):
            raise RuntimeError(self.__class__.ACCOUNT_ALREADY_MANAGED)

    def accept_transactions_visitor(self, a_visitor):
        for summarizing_account in self._accounts:
            summarizing_account.accept_transactions_visitor(a_visitor)

    def accept(self, a_visitor):
        a_visitor.visit_portfolio(self)

    def visit_accounts_with(self, aVisitor):
        for summarizing_account in self._accounts:
            summarizing_account.accept(aVisitor)


class SummarizingAccountVisitor(metaclass=ABCMeta):
    @abstractmethod
    def visit_portfolio(self, portfolio):
        pass

    @abstractmethod
    def visit_receptive_account(self, receptive_account):
        pass


class BalanceVisitor(AccountTransactionVisitor):
    def __init__(self, account):
        self._account = account

    def value(self):
        self._value = 0
        self._account.accept_transactions_visitor(self)
        return self._value

    def visit_deposit(self, deposit):
        self._value += deposit.value()

    def visit_withdraw(self, withdraw):
        self._value -= withdraw.value()

    def visit_certificate_of_deposit(self, certificate_of_deposit):
        self._value -= certificate_of_deposit.value()

    def visit_transfer_deposit(self, transfer_deposit):
        self._value += transfer_deposit.value()

    def visit_transfer_withdraw(self, transfer_withdraw):
        self._value -= transfer_withdraw.value()
