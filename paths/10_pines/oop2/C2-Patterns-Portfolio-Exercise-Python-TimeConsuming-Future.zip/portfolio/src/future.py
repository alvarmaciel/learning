from threading import Thread


class Future:
    def __init__(self, value_supplier):
        self._value = None

        def run():
            self._value = value_supplier()

        self._thread = Thread(target=run)
        self._thread.start()

    def value(self):
        self._thread.join()
        return self._value
