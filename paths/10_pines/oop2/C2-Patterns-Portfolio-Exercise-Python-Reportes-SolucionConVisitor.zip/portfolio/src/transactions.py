from abc import ABCMeta, abstractmethod


class AccountTransaction(metaclass=ABCMeta):
    @abstractmethod
    def value(self):
        pass

    @abstractmethod
    def accept(self, a_visitor):
        pass


class Deposit(AccountTransaction):
    @classmethod
    def register_for_on(cls, value, account):
        return account.register(cls(value))

    def __init__(self, value):
        self._value = value

    def value(self):
        return self._value

    def accept(self, a_visitor):
        return a_visitor.visit_deposit(self)


class Withdraw(AccountTransaction):
    @classmethod
    def register_for_on(cls, value, account):
        return account.register(cls(value))

    def __init__(self, value):
        self._value = value

    def value(self):
        return self._value

    def accept(self, a_visitor):
        return a_visitor.visit_withdraw(self)


class Transfer:
    @classmethod
    def register_for(cls, value, from_account, to_account):
        transfer = Transfer(value, from_account, to_account)
        from_account.register(transfer.withdraw_leg())
        to_account.register(transfer.deposit_leg())

        return transfer

    def __init__(self, value, from_account, to_account):
        self._value = value
        self._from_account = from_account
        self._to_account = to_account
        self._withdraw_leg = TransferWithdraw(self)
        self._deposit_leg = TransferDeposit(self)

    def deposit_leg(self):
        return self._deposit_leg

    def withdraw_leg(self):
        return self._withdraw_leg

    def value(self):
        return self._value


class TransferDeposit(AccountTransaction):
    def __init__(self, transfer):
        self._transfer = transfer

    def value(self):
        return self._transfer.value()

    def accept(self, a_visitor):
        return a_visitor.visit_transfer_deposit(self)

    def transfer(self):
        return self._transfer


class TransferWithdraw(AccountTransaction):
    def __init__(self, transfer):
        self._transfer = transfer

    def value(self):
        return self._transfer.value()

    def accept(self, a_visitor):
        return a_visitor.visit_transfer_withdraw(self)

    def transfer(self):
        return self._transfer


class CertificateOfDeposit(AccountTransaction):
    @classmethod
    def register_for(cls, value, number_of_days, tna, account):
        certificate_of_deposit = cls(value, number_of_days, tna)
        account.register(certificate_of_deposit)

        return certificate_of_deposit

    def __init__(self, value, number_of_days, tna):
        self._value = value
        self._number_of_days = number_of_days
        self._tna = tna

    def accept(self, a_visitor):
        a_visitor.visit_certificate_of_deposit(self)

    def value(self):
        return self._value

    def earnings(self):
        return self._value * (self._tna / 360) * self._number_of_days

    def number_of_days(self):
        return self._number_of_days

    def tna(self):
        return self._tna


class AccountTransactionVisitor(metaclass=ABCMeta):
    @abstractmethod
    def visit_deposit(self, deposit):
        pass

    @abstractmethod
    def visit_withdraw(self, withdraw):
        pass

    @abstractmethod
    def visit_certificate_of_deposit(self, certificate_of_deposit):
        pass

    @abstractmethod
    def visit_transfer_deposit(self, transfer_deposit):
        pass

    @abstractmethod
    def visit_transfer_withdraw(self, transfer_withdraw):
        pass
