from abc import ABCMeta, abstractmethod
from functools import reduce


class Connection(metaclass=ABCMeta):
    @abstractmethod
    def basic_send(self, packet):
        pass

    @abstractmethod
    def send(self, packet):
        pass

    @abstractmethod
    def close(self):
        pass

    @abstractmethod
    def is_closed(self):
        pass


class TcpConnection(Connection):
    def __init__(self, port):
        self._port = port
        self._is_closed = False

    def send(self, packet):
        # Envío la información a través de la conexión
        self.basic_send(packet)

    def basic_send(self, packet):
        # Realiza basic send.
        pass

    def close(self):
        self._is_closed = True

    def is_closed(self):
        return self._is_closed


class InterceptingConnection(Connection):
    _intercepted_connection: Connection

    def __init__(self, intercepted_connection):
        self._intercepted_connection = intercepted_connection

    def send(self, packet):
        return self._intercepted_connection.send(packet)

    def basic_send(self, packet):
        return self._intercepted_connection.basic_send(packet)

    def close(self):
        return self._intercepted_connection.close()

    def is_closed(self):
        return self._intercepted_connection.is_closed()


class TracedConnection(InterceptingConnection):
    def send(self, packet):
        print(f"Log: {packet}")
        return super().send(packet)

    def basic_send(self, packet):
        print(f"Log: {packet}")
        return super().basic_send(packet)


class ZippedConnection(InterceptingConnection):
    def send(self, packet):
        return super().send(self._zip(packet))

    def _zip(self, packet):
        return f"Comprimido({packet})"


class EncryptedConnection(InterceptingConnection):
    def send(self, packet):
        return super().send(self._encrypt(packet))

    def _encrypt(self, packet):
        return f"Encriptado({packet})"


class InterceptingConnectionBuilder:
    _ordered_intercepting_connection_types = [
        TracedConnection,
        EncryptedConnection,
        ZippedConnection,
    ]

    def __init__(self, base_connection):
        self._base_connection = base_connection
        self._intercepting_connection_types_to_apply = []

    def trace(self):
        self._intercepting_connection_types_to_apply.append(TracedConnection)
        return self

    def zip(self):
        self._intercepting_connection_types_to_apply.append(ZippedConnection)
        return self

    def encrypt(self):
        self._intercepting_connection_types_to_apply.append(EncryptedConnection)
        return self

    def build(self) -> Connection:
        return reduce(
            lambda current_connection, intercepting_type: intercepting_type(
                current_connection
            ),
            self._ordered_intercepting_connection_types_to_apply(),
            self._base_connection,
        )

    def _ordered_intercepting_connection_types_to_apply(self):
        return [
            intercepting_type
            for intercepting_type in self._ordered_intercepting_connection_types
            if intercepting_type in self._intercepting_connection_types_to_apply
        ]


# Ejemplo:
def hacer_algo_con(conexion: Connection):
    conexion.send("un paquete")


conexion_base = TcpConnection(8080)
builder = InterceptingConnectionBuilder(conexion_base).encrypt().zip().trace()
una_conexion_wan = builder.build()

hacer_algo_con(una_conexion_wan)

una_conexion_wan.close()
print(una_conexion_wan.is_closed())
print(conexion_base.is_closed())
