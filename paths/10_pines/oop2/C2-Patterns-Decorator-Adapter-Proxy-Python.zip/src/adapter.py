from abc import ABCMeta, abstractmethod
from typing import Callable, Any, Dict


class Canvas:
    def draw(self, string_to_draw):
        # Acá se dibujaría el string. Para el ejemplo lo
        # muestra por consola.
        print(string_to_draw)


class Customer:
    def first_name(self):
        return "FirstName"

    def last_name(self):
        return "LastName"


class Model(metaclass=ABCMeta):
    @abstractmethod
    def as_drawable(self):
        pass


class InputField:
    def __init__(self, model):
        self.model = model

    def draw(self, canvas):
        drawable_model = self.model.as_drawable()
        canvas.draw(drawable_model)


class CustomerModel(Model):
    def __init__(self, customer):
        self.customer = customer

    def as_drawable(self):
        return self.customer.first_name() + " " + self.customer.last_name()


class PluggableAdapter:
    _message_implementations: dict[str, Callable]

    def __init__(self, message_implementations):
        self._message_implementations = message_implementations

    def __getattr__(self, attribute_name):
        return self._message_implementations[attribute_name]


# Ejemplo:
customer = Customer()

# Ejemplo de un adapter especifico.
customer_model = CustomerModel(customer)
input_field = InputField(customer_model)
input_field.draw(Canvas())

# Ejemplo de un adapter genérico. Poner breakpoint en PluggableAdapter.__getattr__
# para ver cómo funciona.
generic_customer_to_model_adapter = PluggableAdapter(
    {"as_drawable": lambda: customer.first_name() + " " + customer.last_name()}
)
input_field_with_generic_adapter = InputField(generic_customer_to_model_adapter)
input_field_with_generic_adapter.draw(Canvas())
