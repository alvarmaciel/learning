class AddressBook:
    @staticmethod
    def addresses_for(customer):
        # Habría que buscar las direcciones para el cliente.
        # Están hardcodeadas por simplicidad.
        return ["Alem 896", "Corrientes 333"]


class PhoneBook:
    @staticmethod
    def phones_for(customer):
        # Acá habría que ir a buscar los teléfonos para el cliente.
        # El resultado está hardcodeado por simplicidad.
        return ["4444-1515", "54-911-2233-4455"]


class Customer:
    def __init__(self):
        # Ejemplo de proxy no polimórfico con el subject.
        self._addresses = LazyVariable(lambda: AddressBook.addresses_for(self))
        # Ejemplo de proxy polimórfico con el subject.
        self._phones = LazyValue(lambda: PhoneBook.phones_for(self))

    # Notar que se devuelve el mismo proxy ya que es polimórfico.
    def phones(self) -> list[str]:
        return self._phones

    # Notar que no se devuelve el proxy sino el subject, debido a que el proxy
    # no es polimórfico con el subject.
    def addresses(self) -> list[str]:
        return self._addresses.value()


class LazyVariable:
    def __init__(self, initializer):
        self._value = None
        self._initializer = initializer

    def value(self):
        if self._value is None:
            self._value = self._initializer()
        return self._value


class LazyValue:
    def __init__(self, object_initializer):
        self._referenced_object = LazyVariable(object_initializer)

    def __getattr__(self, attribute_name):
        return getattr(self._referenced_object.value(), attribute_name)

    # El algoritmo del method lookup en Python funciona distinto para algunos
    # "mensajes especiales"
    # (cf. https://docs.python.org/3/reference/datamodel.html#special-method-lookup).
    # Esto implica que tenemos que definirlos por aparte (aquí lo hacemos manualmente,
    # pero la solución podría ser más general).
    def __len__(self):
        return getattr(self._referenced_object.value(), '__len__')()

    def __iter__(self):
        return getattr(self._referenced_object.value(), '__iter__')()


# Ejemplo
customer = Customer()

# Este ejemplo es para que debugueen cómo funciona la solución.
addresses = customer.addresses()
addresses_size = len(addresses)
ten_pines_address = next(address for address in addresses if address.startswith("Alem"))

print(addresses_size)
print(ten_pines_address)

# También está para que lo debugueen y vean las diferencias con la otra solución.
phones = customer.phones()
phones_size = len(phones)
argentinean_phone = next(phone for phone in phones if phone.startswith("54-"))

print(phones_size)
print(argentinean_phone)

