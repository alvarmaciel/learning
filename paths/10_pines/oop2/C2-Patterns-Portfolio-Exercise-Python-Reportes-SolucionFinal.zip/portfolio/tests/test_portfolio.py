#
# Developed by 10Pines SRL
# License: 
# This work is licensed under the 
# Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. 
# To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/ 
# or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View, 
# California, 94041, USA.
#  
import unittest

from reports import AccountSummary, TransferNet, \
    InvestmentNet, InvestmentEarnings, PortfolioTreePrinter, ReversePortfolioTreePrinter
from accounts import ReceptiveAccount, Portfolio
from transactions import Deposit, Withdraw, Transfer, CertificateOfDeposit


class PortfolioTest(unittest.TestCase):

    def test01_receptive_account_have_zero_as_balance_when_created(self):
        account = ReceptiveAccount()
        self.assertEquals(0, account.balance())

    def test02_deposit_increases_balance_on_transaction_value(self):
        account = ReceptiveAccount()
        Deposit.register_for_on(100, account)

        self.assertEquals(100, account.balance())

    def test03_withdraw_decreases_balance_on_transaction_value(self):
        account = ReceptiveAccount()
        Deposit.register_for_on(100, account)
        Withdraw.register_for_on(50, account)

        self.assertEquals(50, account.balance())

    def test04_portfolio_balance_is_sum_of_managed_accounts_balance(self):
        account1 = ReceptiveAccount()
        account2 = ReceptiveAccount()
        complex_portfolio = Portfolio()
        complex_portfolio.add_account(account1)
        complex_portfolio.add_account(account2)

        Deposit.register_for_on(100, account1)
        Deposit.register_for_on(200, account2)

        self.assertEquals(300, complex_portfolio.balance())

    def test05_portfolio_can_manage_portfolios(self):
        account1 = ReceptiveAccount()
        account2 = ReceptiveAccount()
        account3 = ReceptiveAccount()
        complex_portfolio = Portfolio.create_with(account1, account2)
        composed_portfolio = Portfolio.create_with(complex_portfolio, account3)

        Deposit.register_for_on(100, account1)
        Deposit.register_for_on(200, account2)
        Deposit.register_for_on(300, account3)
        self.assertEquals(600, composed_portfolio.balance())

    def test06_receptive_accounts_knows_registered_transactions(self):
        account = ReceptiveAccount()
        deposit = Deposit.register_for_on(100, account)
        withdraw = Withdraw.register_for_on(50, account)

        self.assertTrue(account.has_registered(deposit))
        self.assertTrue(account.has_registered(withdraw))

    def test07_receptive_accounts_do_not_know_not_registered_transactions(self):
        account = ReceptiveAccount()
        deposit = Deposit(100)
        withdraw = Withdraw(50)

        self.assertFalse(account.has_registered(deposit))
        self.assertFalse(account.has_registered(withdraw))

    def test08_portfolios_knows_transactions_registered_by_its_managed_accounts(self):
        account1 = ReceptiveAccount()
        account2 = ReceptiveAccount()
        account3 = ReceptiveAccount()
        complex_portfolio = Portfolio.create_with(account1, account2)
        composed_portfolio = Portfolio.create_with(complex_portfolio, account3)

        deposit1 = Deposit.register_for_on(100, account1)
        deposit2 = Deposit.register_for_on(200, account2)
        deposit3 = Deposit.register_for_on(300, account3)

        self.assertTrue(composed_portfolio.has_registered(deposit1))
        self.assertTrue(composed_portfolio.has_registered(deposit2))
        self.assertTrue(composed_portfolio.has_registered(deposit3))

    def test09_portfolios_do_not_know_transactions_not_registered_by_its_managed_accounts(self):
        account1 = ReceptiveAccount()
        account2 = ReceptiveAccount()
        account3 = ReceptiveAccount()
        complex_portfolio = Portfolio.create_with(account1, account2)
        composed_portfolio = Portfolio.create_with(complex_portfolio, account3)

        deposit1 = Deposit(100)
        deposit2 = Deposit(200)
        deposit3 = Deposit(300)

        self.assertFalse(composed_portfolio.has_registered(deposit1))
        self.assertFalse(composed_portfolio.has_registered(deposit2))
        self.assertFalse(composed_portfolio.has_registered(deposit3))

    def test10_receptive_account_manage_itself(self):
        account1 = ReceptiveAccount()

        self.assertTrue(account1.manages(account1))

    def test11_receptive_account_do_not_manage_other_account(self):
        account1 = ReceptiveAccount()
        account2 = ReceptiveAccount()

        self.assertFalse(account1.manages(account2))

    def test12_portfolio_manages_composed_accounts(self):
        account1 = ReceptiveAccount()
        account2 = ReceptiveAccount()
        account3 = ReceptiveAccount()
        complex_portfolio = Portfolio.create_with(account1, account2)

        self.assertTrue(complex_portfolio.manages(account1))
        self.assertTrue(complex_portfolio.manages(account2))
        self.assertFalse(complex_portfolio.manages(account3))

    def test13_portfolio_manages_composed_accounts_and_portfolios(self):
        account1 = ReceptiveAccount()
        account2 = ReceptiveAccount()
        account3 = ReceptiveAccount()
        complex_portfolio = Portfolio.create_with(account1, account2)
        composed_portfolio = Portfolio.create_with(complex_portfolio, account3)

        self.assertTrue(composed_portfolio.manages(account1))
        self.assertTrue(composed_portfolio.manages(account2))
        self.assertTrue(composed_portfolio.manages(account3))
        self.assertTrue(composed_portfolio.manages(complex_portfolio))

    def test14_accounts_knows_its_transactions(self):
        account1 = ReceptiveAccount()

        deposit1 = Deposit.register_for_on(100, account1)

        self.assertEquals(1, len(account1.transactions()))
        self.assertTrue(deposit1 in account1.transactions())

    def test15_portfolio_knows_its_accounts_transactions(self):
        account1 = ReceptiveAccount()
        account2 = ReceptiveAccount()
        account3 = ReceptiveAccount()
        complex_portfolio = Portfolio.create_with(account1, account2)
        composed_portfolio = Portfolio.create_with(complex_portfolio, account3)

        deposit1 = Deposit.register_for_on(100, account1)
        deposit2 = Deposit.register_for_on(200, account2)
        deposit3 = Deposit.register_for_on(300, account3)

        self.assertEquals(3, len(composed_portfolio.transactions()))
        self.assertTrue(deposit1 in composed_portfolio.transactions())
        self.assertTrue(deposit2 in composed_portfolio.transactions())
        self.assertTrue(deposit3 in composed_portfolio.transactions())

    def test16_cannot_create_portfolios_with_repeated_account(self):
        account1 = ReceptiveAccount()
        try:
            Portfolio.create_with(account1, account1)
            self.fail()
        except Exception as invalid_portfolio:
            self.assertEquals(Portfolio.ACCOUNT_ALREADY_MANAGED, str(invalid_portfolio))

    def test17_cannot_create_portfolios_with_accounts_managed_by_other_managed_portfolio(self):
        account1 = ReceptiveAccount()
        account2 = ReceptiveAccount()
        complex_portfolio = Portfolio.create_with(account1, account2)
        try:
            Portfolio.create_with(complex_portfolio, account1)
            self.fail()
        except Exception as invalid_portfolio:
            self.assertEquals(Portfolio.ACCOUNT_ALREADY_MANAGED, str(invalid_portfolio))

    def test18a_transfer_must_register_a_transfer_deposit_on_destination_account(self):
        origin_account = ReceptiveAccount()
        destination_account = ReceptiveAccount()

        transfer = Transfer.register_for(100, origin_account, destination_account)

        self.assertTrue(destination_account.has_registered(transfer.deposit_leg()))

    def test18b_transfer_must_register_a_transfer_withdraw_on_origin_account(self):
        origin_account = ReceptiveAccount()
        destination_account = ReceptiveAccount()

        transfer = Transfer.register_for(100, origin_account, destination_account)

        self.assertTrue(origin_account.has_registered(transfer.withdraw_leg()))

    def test18c_transfer_legs_know_transfer(self):
        origin_account = ReceptiveAccount()
        destination_account = ReceptiveAccount()

        transfer = Transfer.register_for(100, origin_account, destination_account)

        self.assertEquals(transfer.deposit_leg().transfer(), transfer.withdraw_leg().transfer())

    def test18d_transfer_knows_its_value(self):
        origin_account = ReceptiveAccount()
        destination_account = ReceptiveAccount()

        transfer = Transfer.register_for(100, origin_account, destination_account)

        self.assertEquals(100, transfer.value(), 0.0)

    def test18e_transfer_must_withdraw_from_origin_account_and_deposit_into_destination_account(self):
        origin_account = ReceptiveAccount()
        destination_account = ReceptiveAccount()

        Transfer.register_for(100, origin_account, destination_account)

        self.assertEquals(-100.0, origin_account.balance())
        self.assertEquals(100.0, destination_account.balance())

    def test19_account_summary_must_provide_human_readable_transactions_detail(self):
        an_account = ReceptiveAccount()
        another_account = ReceptiveAccount()

        Deposit.register_for_on(1000, an_account)
        Withdraw.register_for_on(50, an_account)
        Transfer.register_for(100, an_account, another_account)
        Transfer.register_for(20, another_account, an_account)

        lines = self.account_summary_lines(an_account)

        self.assertEquals([
            "Deposito por 1000",
            "Extraccion por 50",
            "Transferencia por -100",
            "Transferencia por 20",
        ], lines)

    def account_summary_lines(self, origin_account):
        summary = AccountSummary(origin_account)
        lines = summary.lines()
        return lines

    def test20_must_be_able_to_query_transfer_net(self):
        origin_account = ReceptiveAccount()
        destination_account = ReceptiveAccount()

        Deposit.register_for_on(100, origin_account)
        Withdraw.register_for_on(50, origin_account)
        Transfer.register_for(100, origin_account, destination_account)
        Transfer.register_for(250, destination_account, origin_account)

        self.assertEquals(150.0, self.account_transfer_net(origin_account))
        self.assertEquals(-150.0, self.account_transfer_net(destination_account))

    def account_transfer_net(self, account):
        account_transfer_net = TransferNet(account)
        return account_transfer_net.value()

    def test21_certificate_of_deposit_must_withdraw_investment_value(self):
        account = ReceptiveAccount()
        destination_account = ReceptiveAccount()

        Deposit.register_for_on(1000, account)
        Withdraw.register_for_on(50, account)
        Transfer.register_for(100, account, destination_account)
        CertificateOfDeposit.register_for(100, 30, 0.1, account)

        self.assertEquals(100.0, self.investment_net(account))
        self.assertEquals(750.0, account.balance())

    def investment_net(self, account):
        account_investment_net = InvestmentNet(account)
        return account_investment_net.value()

    def test22_must_be_able_to_query_investment_earnings(self):
        account = ReceptiveAccount()

        CertificateOfDeposit.register_for(100, 30, 0.1, account)
        CertificateOfDeposit.register_for(100, 60, 0.15, account)

        investment_earnings = 100 * (0.1 / 360) * 30 + 100 * (0.15 / 360) * 60

        self.assertEquals(investment_earnings, self.investment_earnings(account))

    def investment_earnings(self, account):
        account_investment_earnings = InvestmentEarnings(account)
        return account_investment_earnings.value()

    def test23_account_summary_must_work_with_certificate_of_deposit(self):
        origin_account = ReceptiveAccount()
        destination_account = ReceptiveAccount()

        Deposit.register_for_on(100, origin_account)
        Withdraw.register_for_on(50, origin_account)
        Transfer.register_for(100, origin_account, destination_account)
        CertificateOfDeposit.register_for(1000, 30, 0.1, origin_account)

        lines = self.account_summary_lines(origin_account)

        self.assertEquals([
            "Deposito por 100",
            "Extraccion por 50",
            "Transferencia por -100",
            "Plazo fijo por 1000 durante 30 dias a una tna de 0.1"
        ], lines)

    def test24_must_be_able_to_query_transfer_net_with_certificate_of_deposit(self):
        origin_account = ReceptiveAccount()
        destination_account = ReceptiveAccount()

        Deposit.register_for_on(100, origin_account)
        Withdraw.register_for_on(50, origin_account)
        Transfer.register_for(100, origin_account, destination_account)
        Transfer.register_for(250, destination_account, origin_account)
        CertificateOfDeposit.register_for(1000, 30, 0.1, origin_account)

        self.assertEquals(150.0, self.account_transfer_net(origin_account))
        self.assertEquals(-150.0, self.account_transfer_net(destination_account))

    def test25_portfolio_tree_printer(self):
        account1 = ReceptiveAccount()
        account2 = ReceptiveAccount()
        account3 = ReceptiveAccount()
        complex_portfolio = Portfolio.create_with(account1, account2)
        composed_portfolio = Portfolio.create_with(complex_portfolio, account3)

        account_names = {
            composed_portfolio: "composed_portfolio",
            complex_portfolio: "complex_portfolio",
            account1: "account1",
            account2: "account2",
            account3: "account3"
        }

        lines = self.portfolio_tree_of(composed_portfolio, account_names)

        self.assertEquals([
            "composed_portfolio",
            " complex_portfolio",
            "  account1",
            "  account2",
            " account3"
        ], lines)

    def portfolio_tree_of(self, composed_portfolio, account_names):
        printer = PortfolioTreePrinter(composed_portfolio, account_names)

        return printer.lines()

    def test26_reverse_portfolio_tree_printer(self):
        account1 = ReceptiveAccount()
        account2 = ReceptiveAccount()
        account3 = ReceptiveAccount()
        complex_portfolio = Portfolio.create_with(account1, account2)
        composed_portfolio = Portfolio.create_with(complex_portfolio, account3)

        account_names = {
            composed_portfolio: "composed_portfolio",
            complex_portfolio: "complex_portfolio",
            account1: "account1",
            account2: "account2",
            account3: "account3"
        }

        lines = self.reverse_portfolio_tree_of(composed_portfolio, account_names)

        self.assertEquals([
            " account3",
            "  account2",
            "  account1",
            " complex_portfolio",
            "composed_portfolio"
        ], lines)

    def reverse_portfolio_tree_of(self, composed_portfolio, account_names):
        printer = ReversePortfolioTreePrinter(composed_portfolio, account_names)

        return printer.lines()
