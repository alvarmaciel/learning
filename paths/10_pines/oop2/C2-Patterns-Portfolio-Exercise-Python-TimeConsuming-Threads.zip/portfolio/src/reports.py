from threading import Thread
from time import sleep

from accounts import SummarizingAccountVisitor
from transactions import AccountTransactionVisitor


class AccountSummary(AccountTransactionVisitor):
    def __init__(self, account):
        self._account = account

    def lines(self):
        sleep(0.1)
        self._lines = []

        self._account.accept_transactions_visitor(self)

        return self._lines

    def visit_deposit(self, deposit):
        self._lines.append("Deposito por " + str(deposit.value()))

    def visit_withdraw(self, withdraw):
        self._lines.append("Extraccion por " + str(withdraw.value()))

    def visit_certificate_of_deposit(self, certificate_of_deposit):
        self._lines.append(
            "Plazo fijo por "
            + str(certificate_of_deposit.value())
            + " durante "
            + str(certificate_of_deposit.number_of_days())
            + " dias a una tna de "
            + str(certificate_of_deposit.tna())
        )

    def visit_transfer_deposit(self, transfer_deposit):
        self._lines.append("Transferencia por " + str(transfer_deposit.value()))

    def visit_transfer_withdraw(self, transfer_withdraw):
        self._lines.append("Transferencia por " + str(-transfer_withdraw.value()))


class TransferNet(AccountTransactionVisitor):
    def __init__(self, account):
        self._account = account

    def value(self):
        self._value = 0
        self._account.accept_transactions_visitor(self)
        return self._value

    def visit_deposit(self, deposit):
        pass

    def visit_withdraw(self, withdraw):
        pass

    def visit_certificate_of_deposit(self, certificate_of_deposit):
        pass

    def visit_transfer_deposit(self, transfer_deposit):
        self._value += transfer_deposit.value()

    def visit_transfer_withdraw(self, transfer_withdraw):
        self._value -= transfer_withdraw.value()


class InvestmentNet(AccountTransactionVisitor):
    def __init__(self, account):
        self._account = account

    def value(self):
        sleep(0.5)
        self._value = 0
        self._account.accept_transactions_visitor(self)

        return self._value

    def visit_certificate_of_deposit(self, certificate_of_deposit):
        self._value = certificate_of_deposit.value()

    def visit_deposit(self, deposit):
        pass

    def visit_withdraw(self, withdraw):
        pass

    def visit_transfer_deposit(self, transfer_deposit):
        pass

    def visit_transfer_withdraw(self, transfer_withdraw):
        pass


class InvestmentEarnings(AccountTransactionVisitor):
    def __init__(self, account):
        self._account = account

    def value(self):
        sleep(0.2)
        self._value = 0
        self._account.accept_transactions_visitor(self)

        return self._value

    def visit_certificate_of_deposit(self, certificate_of_deposit):
        self._value += certificate_of_deposit.earnings()

    def visit_deposit(self, deposit):
        pass

    def visit_withdraw(self, withdraw):
        pass

    def visit_transfer_deposit(self, transfer_deposit):
        pass

    def visit_transfer_withdraw(self, transfer_withdraw):
        pass


class PortfolioTreePrinter(SummarizingAccountVisitor):
    def __init__(self, portfolio, account_names):
        self._portfolio = portfolio
        self._account_names = account_names

    def lines(self):
        self._lines = []
        self._spaces = 0

        self._portfolio.accept(self)

        return self._lines

    def visit_portfolio(self, portfolio):
        self._line_for(portfolio)
        self._spaces += 1
        portfolio.visit_accounts_with(self)
        self._spaces -= 1

    def _line_for(self, summarizing_account):
        line = " " * self._spaces + self._account_names[summarizing_account]
        self._lines.append(line)

    def visit_receptive_account(self, receptive_account):
        self._line_for(receptive_account)


class ReversePortfolioTreePrinter:
    def __init__(self, portfolio, account_names):
        self._portfolio = portfolio
        self._account_names = account_names

    def lines(self):
        printer = PortfolioTreePrinter(self._portfolio, self._account_names)
        lines = printer.lines()
        lines.reverse()
        return lines


class AccountSummaryWithInvestmentEarnings:
    def __init__(self, account):
        self._account = account

    def lines(self):
        summary = AccountSummary(self._account)
        investment_earnings = None

        def run():
            nonlocal investment_earnings
            investment_earnings = InvestmentEarnings(self._account).value()

        thread = Thread(target=run)
        thread.start()

        lines = summary.lines()
        thread.join()
        lines.append("Ganancias por " + str(investment_earnings))

        return lines


class AccountSummaryWithAllInvestmentInformation:
    def __init__(self, account):
        self._account = account

    def lines(self):
        summary = AccountSummaryWithInvestmentEarnings(self._account)
        investment_net = None

        def run():
            nonlocal investment_net
            investment_net = InvestmentNet(self._account).value()

        thread = Thread(target=run)
        thread.start()

        lines = summary.lines()
        thread.join()
        lines.append("Inversiones por " + str(investment_net))

        return lines
