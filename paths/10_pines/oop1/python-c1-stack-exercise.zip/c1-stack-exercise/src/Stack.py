# License:
# This work is licensed under the
# Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
# To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/
# or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View,
# California, 94041, USA.
#

class Stack:
    ERROR_EMPTY_STACK = 'Stack is empty'

    def __contains__(self, an_object):
        raise NotImplementedError()

    def __len__(self):
        raise NotImplementedError()

    def push(self, an_object):
        raise NotImplementedError()

    def pop(self):
        raise NotImplementedError()

    def top(self):
        raise NotImplementedError()

    def is_empty(self):
        raise NotImplementedError()
