#
# Developed by 10Pines SRL
# License:
# This work is licensed under the
# Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
# To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/
# or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View,
# California, 94041, USA.
#

import unittest

from src.Stack import Stack


class StackTest(unittest.TestCase):
    def test_new_stacks_must_be_empty(self):
        stack = Stack()

        self.assertTrue(stack.is_empty())

    def test_push_adds_an_element_to_the_stack(self):
        stack = self._empty_stack()

        stack.push('something')

        self.assertFalse(stack.is_empty())

    def test_pop_removes_last_pushed_element_from_the_stack(self):
        stack = self._empty_stack()
        stack.push("Something")

        stack.pop()

        self.assertTrue(stack.is_empty())

    def test_pop_returns_last_pushed_element(self):
        stack = self._empty_stack()
        an_object = "Something"
        stack.push(an_object)

        popped_element = stack.pop()

        self.assertEquals(an_object, popped_element)

    def test_can_stack_more_than_one_element(self):
        first = "First"
        second = "Second"
        stack = self._empty_stack()

        stack.push(first)
        stack.push(second)

        self.assertEquals(second, stack.pop())

    def test_pushing_and_then_popping_makes_no_change_to_the_stack(self):
        first = "First"
        second = "Second"
        third = "Third"
        stack = self._empty_stack()
        stack.push(first)
        stack.push(second)

        stack.push(third)
        stack.pop()

        self.assertEquals(second, stack.pop())

    def test_stack_behaves_lifo(self):
        first = "First"
        second = "Second"
        stack = self._empty_stack()

        stack.push(first)
        stack.push(second)

        self.assertEquals(second, stack.pop())
        self.assertEquals(first, stack.pop())
        self.assertTrue(stack.is_empty())

    def test_top_returns_last_pushed_element(self):
        stack = self._empty_stack()
        an_object = "Something"
        stack.push(an_object)

        top_element = stack.top()

        self.assertEquals(an_object, top_element)

    def test_top_does_not_remove_element_from_stack(self):
        stack = self._empty_stack()
        an_object = "Something"
        stack.push(an_object)

        stack.top()

        self.assertFalse(stack.is_empty())

    def test_size_of_an_empty_stack_is_zero(self):
        stack = self._empty_stack()

        self.assertEquals(0, len(stack))

    def test_push_increments_size_by_one(self):
        stack = self._empty_stack()

        stack.push("element one")
        stack.push("element two")

        self.assertEquals(2, len(stack))

    def test_pop_decrements_size_by_one(self):
        stack = self._empty_stack()
        stack.push("element one")
        stack.push("element two")

        stack.pop()

        self.assertEquals(1, len(stack))

    def test_an_empty_stack_does_not_contain_any_elements(self):
        stack = self._empty_stack()

        self.assertFalse("an object" in stack)

    def test_stack_only_contains_pushed_elements(self):
        stack = self._empty_stack()

        stack.push("pushed object")
        stack.push("another pushed object")

        self.assertTrue("pushed object" in stack)
        self.assertTrue("another pushed object" in stack)
        self.assertFalse("not pushed object" in stack)

    def test_stack_ceases_to_contain_an_element_when_its_last_occurrence_is_popped(self):
        stack = self._empty_stack()
        stack.push("one")
        stack.push("one")
        stack.push("two")

        stack.pop()
        stack.pop()

        self.assertFalse("two" in stack)
        self.assertTrue("one" in stack)

    def test_cannot_pop_from_an_empty_stack(self):
        stack = self._empty_stack()

        self.assertRaisesWithErrorDescription(lambda: stack.pop(), RuntimeError, Stack.ERROR_EMPTY_STACK)

    def test_cannot_top_from_an_empty_stack(self):
        stack = self._empty_stack()

        self.assertRaisesWithErrorDescription(lambda: stack.top(), RuntimeError, Stack.ERROR_EMPTY_STACK)

    def assertRaisesWithErrorDescription(self, lambda_to_try, expected_exception_class, expected_error_description):
        with self.assertRaises(expected_exception_class) as context:
            lambda_to_try()
        self.assertEquals(expected_error_description, str(context.exception))

    def _empty_stack(self):
        return Stack()


if __name__ == "__main__":
    unittest.main()
