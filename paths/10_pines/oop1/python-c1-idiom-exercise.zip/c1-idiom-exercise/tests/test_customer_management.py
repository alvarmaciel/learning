#
# Developed by 10Pines SRL
# License:
# This work is licensed under the
# Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
# To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/
# or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View,
# California, 94041, USA.
#

import unittest

from src.CustomerBook import CustomerBook


class CustomerManagementTest(unittest.TestCase):
    def test_can_not_add_a_customer_with_empty_name(self):
        customer_book = self.empty_customer_book()

        try:
            customer_book.add_customer_named('')
            self.fail()
        except ValueError as exception:
            self.assertEquals(exception.args[0], CustomerBook.ERROR_CUSTOMER_NAME_CAN_NOT_BE_EMPTY)
            self.assertTrue(customer_book.is_empty())

    def test_can_not_remove_not_added_customer(self):
        customer_book = self.empty_customer_book()

        try:
            customer_book.remove_customer_named('John Lennon')
            self.fail()
        except KeyError as exception:
            self.assertEquals(exception.args[0], CustomerBook.ERROR_INVALID_CUSTOMER_NAME)
            self.assertTrue(customer_book.is_empty())

    def test_can_not_add_an_already_existing_customer(self):
        customer_book = self.empty_customer_book()
        customer_book.add_customer_named('George Harrison')

        try:
            customer_book.add_customer_named('George Harrison')
            self.fail()
        except RuntimeError as exception:
            self.assertEquals(exception.args[0], CustomerBook.ERROR_CUSTOMER_ALREADY_EXISTS)
            self.assertEquals(1, customer_book.number_of_customers())

    def empty_customer_book(self):
        return CustomerBook()


if __name__ == "__main__":
    unittest.main()

