#
# Developed by 10Pines SRL
# License:
# This work is licensed under the
# Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
# To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/
# or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View,
# California, 94041, USA.
#

import unittest
from datetime import datetime, timedelta

from src.CustomerBook import CustomerBook


class PerformanceTest(unittest.TestCase):
    def setUp(self):
        self._customer_book = CustomerBook()

    def test_adding_customer_does_not_take_more_than_50_milliseconds(self):
        time_before_running = datetime.now()
        self._customer_book.add_customer_named('John Lennon')
        time_after_running = datetime.now()

        self.assertLess(time_after_running - time_before_running, timedelta(milliseconds=50))

    def test_removing_customer_does_not_take_more_than_100_000_microseconds(self):
        self._customer_book.add_customer_named('Paul McCartney')

        time_before_running = datetime.now()
        self._customer_book.remove_customer_named('Paul McCartney')
        time_after_running = datetime.now()

        self.assertLess(time_after_running - time_before_running, timedelta(microseconds=100_000))


if __name__ == "__main__":
    unittest.main()

